-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: udemy_basic_project
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `abouts`
--

DROP TABLE IF EXISTS `abouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `abouts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci,
  `long_description` text COLLATE utf8mb4_unicode_ci,
  `about_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abouts`
--

LOCK TABLES `abouts` WRITE;
/*!40000 ALTER TABLE `abouts` DISABLE KEYS */;
INSERT INTO `abouts` VALUES (1,'I am a Professional Web Developer','About Me',NULL,NULL,NULL,'2026-07-07 07:34:52','2026-07-07 07:34:52');
/*!40000 ALTER TABLE `abouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_categories`
--

DROP TABLE IF EXISTS `blog_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `blog_category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_categories`
--

LOCK TABLES `blog_categories` WRITE;
/*!40000 ALTER TABLE `blog_categories` DISABLE KEYS */;
INSERT INTO `blog_categories` VALUES (4,'Social',NULL,'2026-07-10 06:53:28'),(5,'React',NULL,NULL),(6,'Laravel',NULL,NULL),(7,'Web Server',NULL,NULL),(8,'Convert',NULL,NULL);
/*!40000 ALTER TABLE `blog_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blogs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `blog_category_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blog_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blog_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blog_tages` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blog_description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` VALUES (1,'5','React design is dedicated to what\'s new in design','upload/blog/1870343296362355.jpeg','react','<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable</p>\r\n<p>Definition Business strategy can be understood as the course of action or set of decisions which assist the entrepreneurs in achieving specific business objectives.</p>\r\n<p>It is nothing but a master plan that the management of a company implements to secure a competitive position in the market, carry on its operations, please customers and achieve the desired ends of the business.</p>\r\n<p>In business, it is the long-range sketch of the desired image, direction and destination of the organization. It is a scheme of corporate intent and action, which is carefully planned and flexibly designed with the purpose of</p>\r\n<ul class=\"services__details__list\">\r\n<li>Achieving effectiveness,</li>\r\n<li>Perceiving and utilizing opportunities,</li>\r\n<li>Mobilising resources,</li>\r\n<li>Securing an advantageous position,</li>\r\n<li>Meeting challenges and threats,</li>\r\n<li>Directing efforts and behaviour and</li>\r\n<li>Gaining command over the situation.</li>\r\n</ul>\r\n<p>A business strategy is a set of competitive moves and actions that a business uses to attract customers, compete successfully, strengthening performance, and achieve organizational goals. It outlines how business should be carried out to reach the desired ends</p>','2026-07-10 09:46:04',NULL),(2,'8','Figma to WordPress','upload/blog/1870343785683629.jpg','figma,wordpress','<p><strong>Looking to convert Figma to WordPress or Figma to Divi professionally?</strong></p>\r\n<p>Converting designs like&nbsp;<strong>Figma, PSD, or XD to WordPress</strong>&nbsp;requires precision. I specialize in building fully functional, pixel-perfect, and high-converting websites using&nbsp;<strong>Divi Builder</strong>&nbsp;and&nbsp;<strong>Elementor Pro</strong>. I ensure a seamless transition from design to a live, responsive website.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>My Core Services:</strong></p>\r\n<ul>\r\n<li><strong>Figma to WordPress</strong>&nbsp;/&nbsp;<strong>Figma to Divi</strong></li>\r\n<li><strong>PSD to WordPress</strong>&nbsp;&amp;&nbsp;<strong>XD to Divi/Elementor</strong></li>\r\n<li><strong>Divi Theme Customization</strong>&nbsp;&amp;&nbsp;<strong>Elementor Pro</strong></li>\r\n<li><strong>Responsive Development</strong>&nbsp;(Mobile, Tablet, Desktop)</li>\r\n<li><strong>Convert HTML to WordPress</strong></li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p><strong>What is Included?</strong></p>\r\n<ul>\r\n<li><strong>Fully Functional Website:</strong>&nbsp;Every delivery is a complete, working site.</li>\r\n<li><strong>Pixel-Perfect Design:</strong>&nbsp;Mirrors your layout exactly.</li>\r\n<li><strong>SEO-Friendly:</strong>&nbsp;Optimized for Google indexing.</li>\r\n<li><strong>Speed &amp; Security:</strong>&nbsp;Fast-loading and secure pages.</li>\r\n<li><strong>Hosting Setup:</strong>&nbsp;Assistance with site migration.</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p><strong>Portfolio link</strong>:</p>\r\n<p>https://www.dreamwebdev.com/portfolio/</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Why Choose Me?</strong></p>\r\n<ul>\r\n<li>Professional standards meeting Fiverr\'s development criteria.</li>\r\n<li>100% Client Satisfaction &amp; On-time delivery.</li>\r\n</ul>\r\n<p>&nbsp;</p>','2026-07-10 09:53:51',NULL);
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('laravel-cache-bdsmrahman@gmail.com|127.0.0.1','i:2;',1783433120),('laravel-cache-bdsmrahman@gmail.com|127.0.0.1:timer','i:1783433120;',1783433120),('laravel-cache-mahbub.webdev@gmail.com|127.0.0.1','i:1;',1783433014),('laravel-cache-mahbub.webdev@gmail.com|127.0.0.1:timer','i:1783433014;',1783433014),('laravel-cache-swapan@gmail.com|127.0.0.1','i:1;',1783503576),('laravel-cache-swapan@gmail.com|127.0.0.1:timer','i:1783503576;',1783503576),('laravel-cache-test@example.com|127.0.0.1','i:1;',1783432995),('laravel-cache-test@example.com|127.0.0.1:timer','i:1783432995;',1783432995);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_slides`
--

DROP TABLE IF EXISTS `home_slides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `home_slides` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_slide` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_slides`
--

LOCK TABLES `home_slides` WRITE;
/*!40000 ALTER TABLE `home_slides` DISABLE KEYS */;
INSERT INTO `home_slides` VALUES (1,NULL,NULL,'upload/home_slide/default.jpg',NULL,'2026-07-07 07:34:52','2026-07-07 07:34:52'),(2,NULL,'Mahbub','upload/home_slide/mahbub.jpg',NULL,NULL,NULL);
/*!40000 ALTER TABLE `home_slides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_03_03_102412_create_personal_access_tokens_table',1),(5,'2026_03_06_024031_create_home_slides_table',1),(6,'2026_03_06_160847_create_abouts_table',1),(7,'2026_03_07_111251_create_multi_images_table',1),(8,'2026_03_08_003132_create_portfolios_table',1),(9,'2026_07_09_110302_create_blog_categories_table',2),(10,'2026_07_10_124614_create_blogs_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multi_images`
--

DROP TABLE IF EXISTS `multi_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `multi_images` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `multi_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multi_images`
--

LOCK TABLES `multi_images` WRITE;
/*!40000 ALTER TABLE `multi_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `multi_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portfolios`
--

DROP TABLE IF EXISTS `portfolios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portfolios` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `portfolio_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portfolio_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portfolio_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portfolio_description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portfolios`
--

LOCK TABLES `portfolios` WRITE;
/*!40000 ALTER TABLE `portfolios` DISABLE KEYS */;
INSERT INTO `portfolios` VALUES (1,'WordPress Divi Theme','I will design a responsive wordpress website using divi theme','upload/portfolio/1870130914760288.png','<p>Are you looking for a professional WordPress website built with the premium Divi theme builder? I specialize in creating high-converting, responsive websites using the Divi theme to ensure your business stands out and converts visitors into active customers.</p>\r\n<p>&nbsp;</p>\r\n<p>As a dedicated Divi expert, I build modern, clean layouts from scratch or optimize your existing setup for maximum speed and performance.&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>My Divi website development services include:</p>\r\n<p>- Complete WordPress Website Development</p>\r\n<p>- Custom Divi Theme Customization &amp; Layout Design</p>\r\n<p>- High-Converting Divi Landing Page Setup</p>\r\n<p>- WooCommerce Integration for E-commerce Stores</p>\r\n<p>- Advanced Speed Optimization &amp; Clean Coding</p>\r\n<p>- SEO Friendly &amp; Mobile-Responsive Design</p>\r\n<p>&nbsp;</p>\r\n<p>Whether you need a sleek business profile or an advanced WooCommerce store, I deliver pixel-perfect designs tailored to your brand goals.</p>\r\n<p>&nbsp;</p>','2026-07-08 01:30:22','2026-07-08 01:30:22'),(2,'WordPress Bug-Fix','WordPress Website Bug Fix','upload/portfolio/1870139592032272.jpg','<p>Are you having problems with your&nbsp;<strong>WordPress site</strong>&nbsp;or&nbsp;<strong>WooCommerce store</strong>? Is your website not working properly, dropping your customers and income?</p>\r\n<p>Don\'t worry, you are at the right place!!</p>\r\n<p>&nbsp;</p>\r\n<p>As an experienced&nbsp;<strong>WordPress developer&nbsp;</strong>with many years of experience, I can fix all the problems and bugs that may affect your website.</p>\r\n<p>&nbsp;</p>\r\n<p>From a broken layout, malfunctioning feature, or an error message, I have the expertise and know-how to fix your WordPress website.</p>\r\n<p>&nbsp;</p>\r\n<p>I thoroughly test my fixes before deploying them to your site within 24 hours</p>\r\n<p>&nbsp;</p>\r\n<p><strong>My Expertise:</strong></p>\r\n<p>&nbsp;</p>\r\n<ul>\r\n<li>Fix WordPress Issues</li>\r\n<li>WordPress Bug Fixes</li>\r\n<li>Fix WordPress Errors</li>\r\n<li>WordPress Malware Removal</li>\r\n<li>WooCommerce Bugs</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p><strong>Fixation Services:</strong></p>\r\n<p>&nbsp;</p>\r\n<ul>\r\n<li>Virus and Recovered from Hacked</li>\r\n<li>️403/404/500 etc. issues</li>\r\n<li>PHP, JS, and CSS Styling</li>\r\n<li>Cloud/Linux/cPanel/Domain/Hosting error issues</li>\r\n<li>Backup and Migration issues</li>\r\n<li>Fix Theme Issue</li>\r\n<li>️Layout issues</li>\r\n<li>Cache Problems</li>\r\n<li>Slow Page Loading</li>\r\n<li>SEO Problems</li>\r\n<li>Database Optimization</li>\r\n<li>️Fix Contact form, widgets, sliders</li>\r\n<li>️And Much More.</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Why Hire Me?</strong></p>\r\n<p>&nbsp;</p>\r\n<ul>\r\n<li>Timely Solutions</li>\r\n<li>24/7 Available</li>\r\n<li>Unlimited Revision</li>\r\n<li>Troubleshooting Expert</li>\r\n<li>100% Satisfaction</li>\r\n</ul>','2026-07-08 03:48:17','2026-07-08 03:48:17'),(3,'Convert figma to divi or elementor','Conver your WordPress website from HTML, Figma, PSD to Divi or Elementor','upload/portfolio/1870140039298410.jpg','<p><strong>Looking to convert Figma to WordPress or Figma to Divi professionally?</strong></p>\r\n<p>Converting designs like&nbsp;<strong>Figma, PSD, or XD to WordPress</strong>&nbsp;requires precision. I specialize in building fully functional, pixel-perfect, and high-converting websites using&nbsp;<strong>Divi Builder</strong>&nbsp;and&nbsp;<strong>Elementor Pro</strong>. I ensure a seamless transition from design to a live, responsive website.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>My Core Services:</strong></p>\r\n<ul>\r\n<li><strong>Figma to WordPress</strong>&nbsp;/&nbsp;<strong>Figma to Divi</strong></li>\r\n<li><strong>PSD to WordPress</strong>&nbsp;&amp;&nbsp;<strong>XD to Divi/Elementor</strong></li>\r\n<li><strong>Divi Theme Customization</strong>&nbsp;&amp;&nbsp;<strong>Elementor Pro</strong></li>\r\n<li><strong>Responsive Development</strong>&nbsp;(Mobile, Tablet, Desktop)</li>\r\n<li><strong>Convert HTML to WordPress</strong></li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p><strong>What is Included?</strong></p>\r\n<ul>\r\n<li><strong>Fully Functional Website:</strong>&nbsp;Every delivery is a complete, working site.</li>\r\n<li><strong>Pixel-Perfect Design:</strong>&nbsp;Mirrors your layout exactly.</li>\r\n<li><strong>SEO-Friendly:</strong>&nbsp;Optimized for Google indexing.</li>\r\n<li><strong>Speed &amp; Security:</strong>&nbsp;Fast-loading and secure pages.</li>\r\n<li><strong>Hosting Setup:</strong>&nbsp;Assistance with site migration.</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p><strong>Portfolio link</strong>:</p>\r\n<p>https://www.dreamwebdev.com/portfolio/</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Why Choose Me?</strong></p>\r\n<ul>\r\n<li>Professional standards meeting Fiverr\'s development criteria.</li>\r\n<li>100% Client Satisfaction &amp; On-time delivery.</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p><strong>Please get in touch with me before ordering</strong>&nbsp;to discuss your project &amp; quote.</p>','2026-07-08 03:55:23','2026-07-08 03:55:23'),(4,'WordPress e-Commerce Website','Develop your  e-Commerce website using on WordPress, using Divi Engine BodyCommerce','upload/portfolio/1870140284347637.jpg','<p>Are you searching for a professional to build a high-performing&nbsp;<strong>WooCommerce website</strong>&nbsp;using&nbsp;<strong>Divi</strong>&nbsp;and&nbsp;<strong>Divi Engine BodyCommerce</strong>?</p>\r\n<p>You\'ve found the right expert. With a deep understanding of WordPress and&nbsp;<strong>eCommerce design</strong>, I will create a custom, fully responsive online store that not only looks stunning but also drives sales. I specialize in building&nbsp;<strong>Divi BodyCommerce</strong>&nbsp;websites tailored to your unique business, from initial setup to full-scale enterprise solutions.</p>\r\n<p>My expertise covers all aspects of&nbsp;<strong>Divi Engine</strong>&nbsp;integration, ensuring every page is perfectly optimized:</p>\r\n<ul>\r\n<li><strong>Custom Product Pages</strong></li>\r\n<li><strong>Checkout &amp; Cart Pages</strong></li>\r\n<li><strong>User Account Pages</strong></li>\r\n<li><strong>Dynamic Product Features</strong></li>\r\n</ul>\r\n<p><strong>Portfolio link</strong>:</p>\r\n<p>https://www.dreamwebdev.com/portfolio/</p>\r\n<p>&nbsp;</p>\r\n<p>I pride myself on providing clear communication and delivering quality work on time. Let\'s build a powerful and profitable online store together.</p>\r\n<p>&nbsp;</p>','2026-07-08 03:59:17','2026-07-08 06:05:01');
/*!40000 ALTER TABLE `portfolios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('gWfH0n4lyRVCecWEqsj1FomQQbJZA9m4OAlMJb9e',2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoicjNwNlNYMXFENERuVFl2eHEydnI4Z3VqOVZ6NERhSGNpNzAxNHlSWiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9hbGwvYmxvZyI7czo1OiJyb3V0ZSI7czo5OiJhbGwuYmxvZ3MiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM6InVybCI7YTowOnt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mjt9',1783698847);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Test User','testuser','test@example.com','2026-07-07 07:34:52','$2y$12$S2kWrXn7yBdLn0NnNazwAOj2/uegArNSxOxb6wm7.YhgWs/uCevp6','T73WHD09nK','2026-07-07 07:35:02','2026-07-07 07:35:02'),(2,'Mahbub WebDev','mahbub','mahbub.webdev@example.com','2026-07-07 07:34:52','$2y$12$hwaJu0rdqh2/qzecNtmLO.Ro3VYrNkOSZjhCPoBa/ieuwgtuCnWG.','XQZCsQ2bgb','2026-07-07 07:34:52','2026-07-07 07:34:52'),(3,'bdsmrahman','bdsmrahman','bdsmrahman@gmail.com',NULL,'$2y$12$ud271f2qVWmnhR.sQKn5w.nmQX7CHDFOgrkQafBOtANknsrv.sxzu',NULL,'2026-07-07 08:03:56','2026-07-07 08:03:56');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-10 22:10:36
